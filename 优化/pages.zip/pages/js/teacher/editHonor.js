var editFruitVue = new Vue({
    el: ".x-body",
    data: {
        info: "",
        typeList: [],
        img: [],
    },
    methods: {
        topReturn: function () {
            window.location.href = "./honor.html"
        },
        topSure: function () {
            editFruitVue.img = [];
            var len = $('#showFruitImages .picContent').length;
            for (var i = 0; i < len; i++) {
                var img = $('#showFruitImages .picContent').eq(i).find('img').attr('src');
                editFruitVue.img.push(img);
            }
            if (editFruitVue.img.length > 0) {
                editFruitVue.img = editFruitVue.img.join();
            } else {
                editFruitVue.img = "";
            }
            var data = {
                "id": args.id,
                "name": $(".class-div1-span1")[0].innerHTML,
                "type": $(".class-div1-span1")[1].innerHTML,
                "level": $(".class-div1-span1")[2].innerHTML,
                "grade": $(".class-div1-span1")[3].innerHTML,
                "date": $(".class-div1-span1")[4].innerHTML,
                "img": editFruitVue.img,
            }
            $.ajax({
                type: "POST",
                url: baseURL + '/saveFruit',
                data: data,
                success: function (data) {
                    layer.alert('修改成功', {
                        icon: 1,
                    },function(){
                        window.location.href = "./honor.html";
                    })
                },
                error: function (response) {
                    layer.alert('修改失败，请重试', {
                        icon: 2,
                    })
                },
            });
        },
        fruitName: function () {
            layui.use('layer', function () {
                var layer = layui.layer
                layer.prompt({
                    formType: 0,
                    value: editFruitVue.info.name,
                    title: '成果名称',
                    area: ['400px', '200px'] //自定义文本域宽高
                }, function (value, index, elem) {
                    $("#id-fruitName").html(value)
                    layer.close(index);
                });
            })
        },
        fruitType: function () {
            $(".class-type-downBox").toggle()
        },
        moreFruitType: function (event) {
            event.cancelBubble = true
            window.location.href = "./fruitType.html"
        },
        fruitRank: function () {
            $(".class-rank-downBox").toggle()
        },
        fruitLevel: function () {
            $(".class-level-downBox").toggle()
        },
        getFruitTime: function () {
            layui.use("laydate", function () {
                var laydate = layui.laydate
                laydate.render({
                    elem: "#id-addFruit-time"
                })
            })
        },
        chooseFruitType: function (type) {
            $(".class-div1-span1")[1].innerHTML = type
            $(".class-type-downBox").toggle()
        },
        chooseRank: function (type) {
            $(".class-div1-span1")[2].innerHTML = type
            $(".class-rank-downBox").toggle()
        },
        chooseLevel: function (type) {
            $(".class-div1-span1")[3].innerHTML = type
            $(".class-level-downBox").toggle()
        }
    }
})
//时间
layui.use("laydate", function () {
    var laydate = layui.laydate
    laydate.render({
        elem: "#id-addFruit-time",
        done: function (value, date, endDate) {
            $("#id-addFruit-time").html(value)
        }
    })
})
//上传附件
layui.use('upload', function () {
    var upload = layui.upload;
    //执行实例
    var uploadInst = upload.render({
        elem: '#uploadFile' //绑定元素
        , url: baseURL + '/upload/' //上传接口
        , accept: "file"
        , before: function (obj) {
            layer.load()
        }
        , choose: function (obj) {
            var files = this.files; //将每次选择的文件追加到文件队列
            //读取本地文件
            obj.preview(function (index, file, result) {
                $('#resName').val(file.name);
            });
        }
        , done: function (res) {
            //上传完毕回调
            layer.closeAll('loading');
            var url = baseURL + '/public' + res.filelink;
            // editFruitVue.img.push(url);
            $('#showFruitImages').append('<div class="picContent"><img style="width: 100%; height: 100%" src="' + url + '"><div class="close">X</div></div>');
        }
        , error: function () {
            //请求异常回调
        }
    });
});
//页面初始化
firstInit();
function firstInit() {
    $.ajax({
        type: "GET",
        url: baseURL + '/getFruit',
        data: { id: args.id },
        success: function (data) {
            if (data.content) {
                data.content = data.content.split(',');
            }
            for (var i = 0; i < data.content.length; i++) {
                editFruitVue.img.push(data.content[i]);
            }
            editFruitVue.info = data;
        }
    });
}

//删除图片
$('#showFruitImages').on('click', '.close', function () {
    $(this).parent().remove();
});
//添加成果类别
var addFruitTypes = function (array) {
    for (let i = 0; i < array.length; i++) {
        var type = array[i].name
        editFruitVue.typeList.push(type)
    }
}
//获取成果类别
var begin = function () {
    $.ajax({
        type: "GET",
        url: baseURL + '/getFruitType',
        success: function (data) {
            // 添加成果类别
            addFruitTypes(data)

        },
        error: function (response) {
            layer.alert('选项加载失败，请重试', {
                icon: 2,
            })
        },
    });
}
begin();
