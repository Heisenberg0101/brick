$(function(){
	var downloadItems = [];
	var downloadItems1 = [];
	var addtion = new Vue({
		el:"#addtion",
		data:{
			auth:null,
			temp:null,
			listProject:null,
			dataList:null,
			chapterList:null,
			bookInfo_id:null,
			bookInfo_zId:null,
			bookInfo_jId:null,
			resourceList:null,
			editList:null,
			chapterLists:null,
			nodeLists:null,
			bookLists:null,
			curr:null,
			lim:null,
			cou:null,
			publisher:null,
			term:null,
			schoolYearId:null,
			schoolYearID:null,
			termId:0,
			termID:0,
			schoolYearName:null,
			teacherId:null
		},
		methods:{
			//点上传人姓名，显示该人的所有资源
			filter:function(publisher,e){
				var bId = addtion.bookInfo_id;
				var zId = addtion.bookInfo_zId;
				var jId = addtion.bookInfo_jId;
				addtion.publisher = publisher;
				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId,publisher);
			},
			addResource:function(){
				var bId = addtion.bookInfo_id+0;
				var zId = addtion.bookInfo_zId+0;
				var jId = addtion.bookInfo_jId+0;
				//上传资源
				window.location.href="instructResource.html"+ '?id=' + bId+'&zId='+zId+'&jId='+jId;
			},
			edit:function(id){
				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resTeachingDetail/'+id,
		          	success: function(data) {
			          	addtion.editList = data;
			          	//编辑资源信息
						ope("编辑",'#book_edits','450px','470px');
		          	},
		          	error: function(response) {
		              layer.alert('失败,请重试',{
		                  icon : 2,
		              })
		          	},
		      	});
			},
			list:function(pId){
				$('.courseware').css('background','#009688');
				addtion.publisher=null;
				addtion.bookInfo_id = pId;
				addtion.dataList = null;
				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/teachingBookDetails/'+pId,
		          	success: function(data) {
		              	if(data.coverImage){
			              	data.coverImage= baseURL +'/public'+data.coverImage;
			          	}else{
			              	data.coverImage= '';
			          	}
			          	addtion.dataList = data;
			          	addtion.chapterList = data.chapterArr;
			          	setTimeout( autoLoad, 1 );
		          	},
		          	error: function(response) {
		              layer.alert('失败,请重试',{
		                  icon : 2,
		              })
		          	},
		      	});
				$('.left').css({display:"none"});
				$('.couseDetail').css({display:"block"});
				addtion.curr =1;
				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
			},
			return:function(){
				$('.courseware').css('background','#009688');
				$('.sharetypes').css('background','#009688');
				addtion.publisher=null;
				addtion.bookInfo_id = 0;
				addtion.bookInfo_zId = 0;
				addtion.bookInfo_jId = 0;
				addtion.curr =1;
				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
				$('.left').css({display:"block"});
				$('.couseDetail').css({display:"none"});
			},
			setZ:function(zId){
				addtion.bookInfo_zId = zId;
				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
			},
			setJie:function(jId){
				addtion.bookInfo_jId = jId;
				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
			},
			removeZj:function(){
				addtion.bookInfo_zId = 0;
				addtion.bookInfo_jId = 0;
				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
			},
			sub:function(bId){
				var resName = $('#resName').val();
			 	var bookId = $('#editbookId').val();
	            var zhangId = $('#zhangId').val();
	            var jieId = $('#jieId').val();
				$.ajax({
		            type: "POST",
		            url: baseURL + '/saveResourceTeaching',
	             	data:{
		                id:bId,
		                resName:resName,
		                bookId:bookId,
		                zhangId:zhangId,
		                jieId:jieId,
		              },
		            success: function(data) {
	                	var now=addtion.curr;
		          	    var number=addtion.lim;
		          	    var cou=addtion.cou;
		          	    var start1=(now-1)*number;
		                var end1=now*number;
		          	    //判断最后一页显示是不是最后一条
		          	    if(cou%number==1 && cou-start1==1){
		          	    	start1 = start1-number;
		          	    }
		                autoLoadResource(start1,end1,addtion.termId,addtion.schoolYearId,addtion.publisher);
		                layer.closeAll();
		            },
		            error: function(response) {
		                layer.alert('保存失败，请重试',{
		                    icon : 2,
		                })
		            },
		        });
		        // window.location.href="addition.html";
			},
			removeRes:function(bId){
				layer.confirm("确定删除？", {fixed: false, shade: false}, function(){
					$.ajax({
			            type: "get",
			            url: baseURL + '/resTeachingDel/'+bId,
		             	data:{
			                id:bId
		              	},
			            success: function(data) {
			                var bId = bId;
			                var now=addtion.curr;
			          	    var number=addtion.lim;
			          	    var cou=addtion.cou;
			          	    var start1=(now-1)*number;
			                var end1=now*number;
			          	    //判断最后一页显示是不是最后一条
			          	    if(cou%number==1 && cou-start1==1){
			          	    	start1 = start1-number;
			          	    }
			          	    layer.alert('删除成功！',{
			                    icon : 1,
			                })
			                autoLoadResource(start1,end1,addtion.termId,addtion.schoolYearId,addtion.publisher);
			            },
			            error: function(response) {
			                layer.alert('删除失败，请重试',{
			                    icon : 2,
			                })
			            },
			        });
				})
		        // window.location.href="addition.html";
			},
			updateItems:function(){
				var data = $('.selectRes');
				downloadItems = [];
				downloadItems1 = [];
				for (var i = 0; i < data.length; i++) {
					var src = data[i].value.substr(data[i].value.length-3);
		            result = src.toLowerCase();
					if(data[i].checked==true){
						if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif' && result!='pdf'){
			          		downloadItems.push(data[i].value);
			        	}else{
			        		downloadItems1.push(data[i].value);
			        	}

					}
				}
			}
		}
	});
	function autoLoad(){
		$('.list ul li p').clickdown();
      	$('.list-se p[class=title]').clickup();
		$('.list>ul>li').ad();
	}

	//检查权限
    // authCheck();
    function authCheck(){
      	$.ajax({
          	type: "GET",
          	url: baseURL + '/authCheck',
          	data:{action:"addtion/edit"},
          	success: function(data) {
              addtion.auth = data.auth;
          	},
          	error: function(response) {
              layer.alert('失败,请重试',{
                  icon : 2,
              })
          	},
      	});
    }

    //弹窗
	function ope(title,obj,width,height){
		layui.use('layer',function(){
			var layer = layui.layer;
		    layer.open({
			  type: 1,
			  title:title,
			  area: [width, height],
			  content: $(obj),
			  shadeClose: true,
	          fixed: false,
	          shade: false,
			  end: function(index, layero){
				   $(obj).css({display:"none"});
				},
			});
		});
   	}

 	begin();
    function begin(){
    	//五认真检查个人跳转
    	addtion.teacherId = args.teacherId;
    	//获取当前学期
        $.ajax({
            type: "GET",
            url: baseURL + '/termNow',
            success: function(response) {
                addtion.termId = response;
        		//获取当前学年
                $.ajax({
		            type: "GET",
		            url: baseURL + '/schoolYearNow',
		            success: function(response) {
		            	addtion.schoolYearId = response;
        				//加载资源
        				autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
		            },
		            error: function(response) {
		                layer.alert(response.responseJSON,{
		                    icon : 2,
		                })
		            },
		        });
                //教学管理课本列表
		      	$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resTeachingList',
		          	data:{term:addtion.termId,
		          		  teacherId:addtion.teacherId
		          		},
		          	success: function(data) {
		              	addtion.temp = data.datas;
		              	addtion.listProject = data.list;
		          	},
		          	error: function(response) {
		              	layer.alert('失败,请重试',{
		                  	icon : 2,
		              	})
		          	},
		      	});
		      	//课本列表
			    $.ajax({
			        type: "GET",
			        url: baseURL + '/resTeachingForSelect',
			        data:{term:addtion.termId},
			        success: function(data) {
			            addtion.bookLists = data.list;
			        },
			        error: function(response) {
			            layer.alert('课本列表加载失败，请重试',{
			                icon : 2,
			            })
			        },
			    });
            },
            error: function(response) {
                layer.alert(response.responseJSON,{
                    icon : 2,
                })
            },
        });

	    //章节列表
	    $.ajax({
	        type: "GET",
	        url: baseURL + '/chapterListForSelect',
	        success: function(data) {
	            addtion.chapterLists = data.chapter;
	            addtion.nodeLists = data.node;
	        },
	        error: function(response) {
	            layer.alert('章节列表加载失败，请重试',{
	                icon : 2,
	            })
	        },
	    });

	    //获取学期
        $.ajax({
            type: "GET",
            url: baseURL + '/schoolYearList',
            success: function(data) {
                addtion.term = data;
            },
            error: function(response) {
                layer.alert('学期列表加载失败，请重试',{
                    icon : 2,
                })
            },
        });
    }

    /*加载资源*/
	function autoLoadResource(start,end,termId,schoolYearId,publisher){
		//五认真检查个人跳转
		if(args.publisher!=null) publisher = args.publisher;
		var bId = addtion.bookInfo_id;
		var zId = addtion.bookInfo_zId;
		var jId = addtion.bookInfo_jId;
		// var type = addtion.type==null?6:addtion.type;
		if(publisher!=null){
			var data = {publisher:publisher,term:termId,schoolYearId:schoolYearId,teacherId:args.teacherId};
		}else{
			var data = {term:termId,schoolYearId:schoolYearId};
		}
		$.ajax({
          	type: "GET",
          	url: baseURL + '/resourceTeaching/'+bId+'/'+zId+'/'+jId,
          	data:data,
          	success: function(data) {
          		for (var i = 0; i < data.length; i++) {
	      			if(data[i]['resource_url']){
	      				  var result = data[i]['resource_url'].substr(data[i]['resource_url'].length-3);
			              result = result.toLowerCase();
			        	  data[i]['resource_url'] = data[i]['resource_url'];
			             if( result =='pdf'){
	          			    data[i]['resource_urlOnline'] = data[i]['resource_url'];
	          			  }
	                      else if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif'){
		          			data[i]['resource_urlOnline'] = 'https://view.officeapps.live.com/op/view.aspx?src='+data[i]['resource_url'];
		        			}else{
				                data[i]['resource_urlOnline'] = 'BookPic.html?u=' + data[i]['resource_url'];
				                data[i]['resource_url'] = 'BookPic.html?u=' + data[i]['resource_url'];
				              }
	      			}
	      		}
              	addtion.resourceList = data.slice(start,end);
              	layui.use('laypage', function(){
	                var laypage = layui.laypage;
	                laypage.render({
	                     elem: 'bookPage'
	                    ,count: data.length//数据总数，从服务端得到
	                    ,limit:10
	                    ,layout: ['count', 'prev', 'page', 'next']
	                    ,curr:addtion.curr
	                    ,jump: function(obj, first){
	                      //obj包含了当前分页的所有参数，比如：
	                      var nowpage=obj.curr; //得到当前页，以便向服务端请求对应页的数据。
	                      var nownumber=obj.limit; //得到每页显示的条数
	                      addtion.curr=obj.curr;
	                      addtion.lim=obj.limit;
	                      addtion.cou=data.length;
	                      if(!first){
	                        var start=(nowpage-1)*nownumber;
	                        var end=nowpage*nownumber;
	                        addtion.resourceList =data.slice(start,end);
	                      }
	                   }
	                });
	              });
          	},
          	error: function(response) {
              // layer.alert('失败,请重试',{
              //     icon : 2,
              // })
          	},
      	});
	}

	//搜索查询
    $("#schoolYearId").change(function(){
        var schoolYearId = $("#schoolYearId").val();
        //获取当前学期
        $.ajax({
            type: "GET",
            url: baseURL + '/termNow',
            data:{schoolYearId:schoolYearId},
            success: function(response) {
                addtion.termId = response;
                addtion.schoolYearId = schoolYearId;
                //加载资源
                autoLoadResource(0,10,addtion.termId,addtion.schoolYearId);
		        //教学管理课本列表
		      	$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resTeachingList',
		          	data:{term:addtion.termId,
		          		  teacherId:addtion.teacherId
		          		},
		          	success: function(data) {
		              	addtion.temp = data.datas;
		              	addtion.listProject = data.list;
		          	},
		          	error: function(response) {
		              	layer.alert('失败,请重试',{
		                  	icon : 2,
		              	})
		          	},
		      	});
		      	//课本列表
			    $.ajax({
			        type: "GET",
			        url: baseURL + '/resTeachingForSelect',
			        data:{term:addtion.termId},
			        success: function(data) {
			            addtion.bookLists = data.list;
			        },
			        error: function(response) {
			            layer.alert('课本列表加载失败，请重试',{
			                icon : 2,
			            })
			        },
			    });
            },
            error: function(response) {
                layer.alert(response.responseJSON,{
                    icon : 2,
                })
            },
        });
    })

	$('#batch').click(function(){
		$('#checkAll').show();
		$("a[name='selectA']").show();

	})

	$('#checkAll').click(function(){
		downloadItems = [];
		downloadItems1 = [];
		var data = $('.selectRes');
		for (var i = 0; i < data.length; i++) {
			var src = data[i].value.substr(data[i].value.length-3);
		    result = src.toLowerCase();
			if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif'){
		         downloadItems.push(data[i].value);
		      }else{
		        downloadItems1.push(data[i].value);
		       }
		}

     	$(".selectRes").prop('checked',true);
		$('#download').show();
		/*if($(this).attr('checked')){
		 	}else{
	     	$(".selectRes").prop('checked',false);
	   	} */
	})

  	var btn = document.getElementById('download');

 	function download(name, href) {
      	var a = document.createElement("a"), //创建a标签
          	e = document.createEvent("MouseEvents"); //创建鼠标事件对象
      	e.initEvent("click", false, false); //初始化事件对象
      	a.href = href; //设置下载地址
      	a.download = name; //设置下载文件名
      	a.dispatchEvent(e); //给指定的元素，执行事件click事件
  	}

  	//给多文件下载按钮添加点击事件
  	btn.onclick = function name(params) {
   	   	for (let index = 0; index < downloadItems.length; index++) {
	     	 download('第' + index + '个文件', downloadItems[index]);
      	}
	    for(var i=0;i<downloadItems1.length;i++){
	      	 var index = downloadItems1[i].indexOf('?u=');
	      	 downloadItems1[i] = downloadItems1[i].substring(index+3);
	      }
	    downloadItems1 = downloadItems1.join(',');
      	if(downloadItems1.length>0){
      		window.open('BookPic.html?u=' + downloadItems1,'_blank');
      	}
  	}


});
