$(function(){
        var nowDate = new Date();
        var nowYear=nowDate.getFullYear();
        var nowMonth=nowDate.getMonth()+1;
        if(nowMonth<8){
          var time=nowYear-1;
        }else{
          var time=nowYear;
        }
        var teacher = new Vue({
            el: "#teacher",
            data: {
                unbindteachers:null,
                teachersubjects:null,
                bindindsteachers:null,
                teachertype:null,
                lists: null,
                message:null,
                organization:null,
                teachermessage:null,
                schoolTree: null,
                teacher: null,
                classModel: null,
                subjectmessage:null,
                allsubject:null,
                allsubjectlength:null,
                teachersubject:null,
                lists1:null,
                auth:null,
                subjects: [{
                    name: "加载中..."
                  }],
                typesubject:'所有学科',
                  },
            methods:{
               //跳转教师档案
            skipTeacher:function(teacherId){
              window.location.href="teacherProfile.html?teacherId="+teacherId;
            },
             saveTeacher: function() {
            // 生成要提交的数据集
            var allmeaasge =  teacher.teachermessage;
            delete teacher.project;
            delete teacher.projectArray;
            var classes = [];
            getChecked(teacher.schoolTree, classes);
            allmeaasge.classes = JSON.stringify(classes);
            allmeaasge.login = JSON.stringify(allmeaasge.login);
            $.ajax({
              type: "POST",
              url: baseURL + '/teacherbind?schoolYear='+time,
              data: allmeaasge,
              success: function(response) {

               layui.use('layer',function(){
                    var layer =layui.layer;
                    layer.alert('教师信息保存成功！', {icon: 1});
                });
                location.reload();
              },
              error: function(response) {
                 layui.use('layer',function(){
                    var layer =layui.layer;
                    layer.alert('教师信息保存失败！', {icon: 5});
                });
              }
            });

            teacher.login = JSON.parse(teacher.login);
            teacher.classes = JSON.parse(teacher.classes);

          },
          unboundTeacher: function() {
            var teacherID = teacher.teachermessage.id;
              $.ajax({
                type: "GET",
                url: baseURL + '/unbound',
                data: {
                  teacherID:teacherID
                },
                success: function(response) {
                  layui.use('layer',function(){
                      var layer =layui.layer;
                      layer.alert('教师解绑成功！', {icon: 6});
                  });
                    teacherajax();
                },
                error: function(response) {
                  alert("教师解绑失败!");
                }
              });
            },
          deleteTeacher: function(id) {
            var teacherID = id;
            layer.confirm("确定删除？", {fixed: false, shade: false}, function(){
                $.ajax({
                  type: "GET",
                  url: baseURL + '/unbound',
                  data: {
                    teacherID:teacherID
                  },
                  success: function(response) {
                    layui.use('layer',function(){
                        var layer =layui.layer;
                        layer.alert('教师解绑成功！', {icon: 6});
                    });
                      allteacher();
                  },
                  error: function(response) {
                    alert("教师解绑失败!");
                  }
                });
            }) 
            },
                  // 切换老师教授课程
            toggleSubject: function(classModel, subject) {
              //设置zetree
                var setting = {
                    check:{
                        enable:true,
                        chkStyle: "checkbox",
                        chkboxType: { "Y": "", "N": "" }
                    },
                    data: {
                        simpleData: {
                            enable: true
                        }
                    }
                };

              var nodes = [
                  {name: "科技", children: [
                    {name: "电脑制作"},
                    {name: "汽车文化"}
                  ]},
                  {name: "体育", children: [
                    {name: "篮球"},
                    {name: "足球"}
                  ]}
                ];
              //alert(JSON.stringify(subject));
              if(subject.name == '选修'){
                 layui.use('layer', function(){
                  var layer = layui.layer;
                      index = layer.open({
                          type: 1 ,
                          title:'选修课绑定',
                          area: ['500px','400px'],
                          content: $('#notice'),
                          fixed:false,
                          end:function(){
                            $('#notice').css({display:'none'});
                          }
                        });
                    });

                    $.fn.zTree.init($("#treeDemo"), setting, nodes);
                    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
                    console.log(zTree);
                    zTree.expandAll(false);
              }
              var index = classModel.projectIDs.indexOf(subject.id + '');
              if (index === -1) {
                classModel.projectIDs.push(subject.id + '');
              } else {
                classModel.projectIDs.splice(index, 1);
              }
            },
              showTeacher:function(tea){
               // alert(JSON.stringify(tea));
                 if (!tea.classes) {
                      tea.classes = "[]";
                    }
                  //将tea.classes由字符串形式变换成数组形式
                if (typeof tea.classes == "string") {
                  tea.classes = JSON.parse(tea.classes);
                }
               //alert(JSON.stringify(tea.classes));
               //selectedClassList数组类型
               var selectedClassList = tea.classes;
               var selectedClassMap = {};
               for (var pos in selectedClassList) {
                  var selectedClass = selectedClassList[pos];
                  //将数组的每条元素去除以{}形式保存
                  //alert(JSON.stringify(selectedClassList[pos]));
                  selectedClassMap[selectedClass.organizeID] = selectedClass;
                }

                if (!tea.login || tea.login === '0') {
                  tea.login = {
                    username: "",
                    password: ""
                  };
                }

              if (typeof tea.login === "string") {
                if (tea.login === "") {
                  tea.login = JSON.stringify({
                    username: "",
                    password: ""
                  });
                }

                tea.login = JSON.parse(tea.login);
              }
               teacher.teachermessage=tea;
                // 初始化学校所有班级
               var organization = getOrganization();
               setChecked(organization, selectedClassMap);
               //alert(JSON.stringify(selectedClassMap));
               //搭建班级复选框
               teacher.schoolTree = organization;
               layui.use('layer', function(){
                  var layer = layui.layer;
                  index = layer.open({
                      type: 1 ,
                      title:[teacher.teachermessage.name+' 教师信息管理 ','color:#1AB394;font-size:18px;'],
                      area: ['430px','480px'],
                      fixed:false,
                      content: $('#message'),
                    });
                });

              },
               onChecked: function(model) {
                //alert(JSON.stringify(model));
                  // 如果是全校、年级的话，不用弹框
                  if (!model.checked || model.children) {
                    return;
                  }
                  //获取全部课程
                $.ajax({
                    type: "GET",
                    url: baseURL + '/project',//获取国家课程
                    data:{type:0},
                    success: function(response) {
                      teacher.subjects = response;
                      //alert(JSON.stringify(teacher.subjects));
                    },
                    error: function(response) {
                      alert('error');
                    }
                  });
                  // 准备环境
                  teacher.teacher = this.teacher;
                 // teacher.subjects = this.subjects;
                  //alert(JSON.stringify(bindTeacher.subjects));
                  teacher.classModel = model;
                  teacher.message=model;
                  // 关闭窗口
                  layui.use('layer', function(){
                  var layer = layui.layer;
                      index = layer.open({
                          type: 1 ,
                          title:[teacher.teachermessage.name+'老师 '+teacher.message.className+' 工作情况','color:#1AB394;font-size:18px;'],
                          area: ['430px','480px'],
                          content: $('#bindTeacher'),
                          fixed:false,
                        });
                    });

                },
              choosesubject:function(projectID,name){
                $('#allsub').removeClass('sub');
                $(".choosecur").removeClass('sub');
                for(var i=0;i<$(".choosecur").length;i++){
                    if($(".choosecur").eq(i).html() == name){
                      $(".choosecur").eq(i).addClass('sub');
                    }
                }
                teacher.typesubject=name;
                 teacher.lists1=[];
                 //alert(JSON.stringify(teacher.lists));
                  $.ajax({
                    type:"POST",
                    url: baseURL + '/chooseSubject',
                    data:{
                      schoolYear:time,
                      projectID: projectID
                    },
                   success: function(data) {
                        var arr=[];
                        var index=0;
                        for(var i in data){
                            arr[index]=data[i];
                            index++;
                        }
                       // alert(JSON.stringify(arr));
                        teacher.lists1=arr;
                       // alert(JSON.stringify(teacher.lists));
                    },
                    error:function(){
                      alert('教师列表获取失败!');
                    }
                  })
              },
              allchoose:function(){
                  $('#allsub').addClass('sub');
                  teacher.typesubject=$("#allsub").html();
                  teacherajax();
                  subjectajax();
              }
            }
       });

     //初始化按班级查看教师列表
        teacherajax();
        // Ajax请求数据方法
        function teacherajax() {
            //请求地址列表
            $.ajax({
                type: "POST",
                url: baseURL + '/getAllTeacher?schoolYear='+time,
                success: function(data) {
                    var organization = getOrganization();
                    teacher.schoolTree = organization;
                    teacher.lists = data;
                    //alert(JSON.stringify(data));
                },
                error: function(response) {
                    layer.alert('教师列表加载失败，请重试',{
                        icon : 2,
                    })
                },
            });
        }

        //初始化全部绑定的教师
        allteacher();
        function allteacher(){
               //获取教师列表
            $.ajax({
              type: "GET",
              url: baseURL + '/getTeacher?schoolYear='+time,
              success: function(response) {
                //alert(JSON.stringify(response));
               teacher.bindindsteachers = response.slice(0,10);
               //已绑定教师列表显示分页
               layui.use('laypage',function(){
                  var laypage = layui.laypage;
                    laypage.render({
                      elem: 'teacherpage'
                      ,limit:10
                      ,count: response.length
                      ,layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip']
                      ,jump: function(obj, first){
                          //首次不执行
                          if(!first){
                            var start=(obj.curr-1)*obj.limit;
                            var end=obj.curr*obj.limit;
                            teacher.bindindsteachers = response.slice(start,end);
                          }
                        }
                    });
               });
               // alert(JSON.stringify(teacher.bindindsteachers));
              },
              error: function(response) {
                alert('error'); layer.alert('教师列表加载失败，请重试',{
                        icon : 2,
                    })
              }
            });
        }

         //初始化课程列表
    subjectajax();
    function subjectajax(){
          //获取课程列表
        $.ajax({
          type: "GET",
          url: baseURL + '/project',
          success: function(response) {
              teacher.allsubject = response;
              teacher.allsubjectlength = response.length;
              //alert(JSON.stringify(response));
          },
          error: function(response) {
             layui.use('layer', function(){
                  var layer = layui.layer;
                  layer.msg('课程信息获取失败 !', {icon: 5});
                });
          }
        });
    }

           //初始化按未绑定查看教师列表
        // unbindteacher();
        function unbindteacher(){
               //获取教师列表
            $.ajax({
              type: "POST",
              url: baseURL + '/getUnbindTeacher?schoolYear=2017',
              success: function(response) {
                var all=[];
                var arr=response.unbindName;
                var i=0;
                for (var index in arr){
                    all[i]=arr[index];
                    i=i+1;
           //var all[i]=arr[index];
          }
              teacher.unbindteachers=all.slice(0,10);

                  //已绑定教师列表显示分页
               layui.use('laypage',function(){
                  var laypage = layui.laypage;
                    laypage.render({
                      elem: 'teacherpage1'
                      ,limit:10
                      ,count: all.length
                      ,layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip']
                      ,jump: function(obj, first){
                          //首次不执行
                          if(!first){
                            var start=(obj.curr-1)*obj.limit;
                            var end=obj.curr*obj.limit;
                            teacher.unbindteachers = all.slice(start,end);
                          }
                        }
                    });
               });
              },
              error: function(response) {
                alert('error'); layer.alert('教师列表加载失败，请重试',{
                        icon : 2,
                    })
              }
            });
        }

      function setChecked (node, selectedClassMap) {
        // 清空上个老师的影响
        node.checked = false;
        node.type = "normal";

        var selectedClass = selectedClassMap[node.ID + ""];
        if (selectedClass) {
          node.checked = true;
          node.type = selectedClass.type;

          // 4.0版本提供了班级相关的课程数据，默认为空
          if (!selectedClass.projectIDs) {
            selectedClass.projectIDs = [];
          }

          node.projectIDs = selectedClass.projectIDs;
        }

        var children = node.children;
        for (var pos in children) {
          var child = children[pos];
          setChecked(child, selectedClassMap);
        }
      };
     function getOrganization() {
           $.ajax({
                type: "GET",
                url: baseURL + '/organization?schoolYear='+time,
                success: function(response) {
                    teacher.organization = response;
                    //alert(JSON.stringify(response));
                },
                error: function(response) {
                     teacher.organization = [];
                }
            });
            var originData = JSON.parse(JSON.stringify(teacher.organization));
            var schoolTree = {
              ID: 0,
              name: "全校",
              checked: false,
              children: []
            };

            for (var gradePos in originData) {
              var grade = originData[gradePos];
              grade.ID = grade.gradeID;
              grade.name = grade.grade;
              grade.children = grade.classes;
              grade.checked = false;
              for (var classPos in grade.children) {
                var classObj = grade.children[classPos];
                classObj.name = classObj.className;
                classObj.checked = false;
                classObj.type = "normal";
                classObj.projectIDs = [];
              }

              schoolTree.children.push(grade);
            }
          //alert(JSON.stringify(schoolTree));
            return schoolTree;
          };

    function  setChecked(node, selectedClassMap) {
                // 清空上个老师的影响
                node.checked = false;
                node.type = "normal";

                var selectedClass = selectedClassMap[node.ID + ""];
                if (selectedClass) {
                  node.checked = true;
                  node.type = selectedClass.type;

                  // 4.0版本提供了班级相关的课程数据，默认为空
                  if (!selectedClass.projectIDs) {
                    selectedClass.projectIDs = [];
                  }

                  node.projectIDs = selectedClass.projectIDs;
                }

                var children = node.children;
                for (var pos in children) {
                  var child = children[pos];
                  setChecked(child, selectedClassMap);
                }
              };


  function  getChecked(node, selectedClassList) {
      if (node.checked) {
        if (!node.type) {
          node.type = "normal";
        }

        selectedClassList.push({
          organizeID: node.ID,
          type: node.type,
          projectIDs: node.projectIDs
        });
      }

      var children = node.children;
      for (var pos in children) {
        var child = children[pos];
        getChecked(child, selectedClassList);
      }
    };

    $('#change').click(function(){
        layui.use('layer',function(){
            var layer =layui.layer;
            var index = layer.alert('教师信息修改成功！', {icon: 1});
        });
        layer.close(index);
    });
  $('.changetype').click(function(){
      teacher.teachertype=$(this).html();
  });

    //搜索查询
    $("#chooselist").click(function(){
        var name = $("#name").val();
        // 发送给后台搜索
        $.ajax({
          type: "GET",
          url: baseURL + '/getTeacher?schoolYear='+time+"&name="+name,
          success: function(response) {
           teacher.bindindsteachers = response.slice(0,10);
           //已绑定教师列表显示分页
           layui.use('laypage',function(){
              var laypage = layui.laypage;
                laypage.render({
                  elem: 'teacherpage'
                  ,limit:10
                  ,count: response.length
                  ,layout: ['count', 'prev', 'page', 'next', 'limit', 'refresh', 'skip']
                  ,jump: function(obj, first){
                      //首次不执行
                      if(!first){
                        var start=(obj.curr-1)*obj.limit;
                        var end=obj.curr*obj.limit;
                        teacher.bindindsteachers = response.slice(start,end);
                      }
                    }
                });
           });
          },
          error: function(response) {
            alert('error'); layer.alert('教师列表加载失败，请重试',{
                    icon : 2,
                })
          }
        });
    })

  //检查权限
    authCheck();
    function authCheck(){
      $.ajax({
          type: "GET",
          url: baseURL + '/authCheck',
          data:{action:"teacherList/edit"},
          success: function(data) {
              teacher.auth = data.auth;
          },
          error: function(response) {
              layer.alert('失败,请重试',{
                  icon : 2,
              })
          },
      });
    }

});
