$(function(){
	$('a.media').media({width:1200, height:800});

	var downloadItems = [];
	var downloadItems1 = [];
	var addtion = new Vue({
		el:"#addtion",
		data:{
			auth:null,
			temp:null,
			listProject:null,
			dataList:null,
			chapterList:null,
			bookInfo_id:null,
			bookInfo_zId:null,
			bookInfo_jId:null,
			resourceList:null,
			editList:null,
			chapterLists:null,
			nodeLists:null,
			bookLists:null,
			type:null,
			term:null,
          	schoolYearId:0,
          	termId:null
		},
		methods:{
			//点上传人姓名，显示该人的所有资源
			filter:function(publisher){
				var bId = addtion.bookInfo_id;
				var zId = addtion.bookInfo_zId;
				var jId = addtion.bookInfo_jId;
				var type = addtion.type==null?3:addtion.type;

				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resourceUpload/'+bId+'/'+zId+'/'+jId+'/'+type,
		          	data:{publisher:publisher,term:addtion.termId},
		          	success: function(data) {
		          		for (var i = 0; i < data.length; i++) {
			      			if(data[i]['resource_url']){
	      				  		var result = data[i]['resource_url'].substr(data[i]['resource_url'].length-3);
			              		result = result.toLowerCase();
			        	  		data[i]['resource_url'] = data[i]['resource_url'];
				              	if( result =='pdf'){
		          			    	data[i]['resource_urlOnline'] = data[i]['resource_url'];
		          			  	}else if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif'){
			          				data[i]['resource_urlOnline'] = 'https://view.officeapps.live.com/op/view.aspx?src='+data[i]['resource_url'];
			        			}else{
					                data[i]['resource_urlOnline'] = 'BookPic.html?u=' + data[i]['resource_url'];
					                data[i]['resource_url'] = 'BookPic.html?u=' + data[i]['resource_url'];
					            }
			      			}
			      		}
		              	addtion.resourceList = data.slice(0,10);
		              	layui.use('laypage', function(){
			                var laypage = layui.laypage;
			                laypage.render({
			                     elem: 'bookPage'
			                    ,count: data.length//数据总数，从服务端得到
			                    ,limit:10
			                    ,layout: ['count', 'prev', 'page', 'next', 'limit']
			                    ,curr:addtion.curr
			                    ,jump: function(obj, first){
			                      //obj包含了当前分页的所有参数，比如：
			                      var nowpage=obj.curr; //得到当前页，以便向服务端请求对应页的数据。
			                      var nownumber=obj.limit; //得到每页显示的条数
			                      if(!first){
			                        var start=(nowpage-1)*nownumber;
			                        var end=nowpage*nownumber;
			                        addtion.resourceList =data.slice(start,end);
			                      }
			                   }
			                });
			             });
		          	},
		          	error: function(response) {
		              layer.alert('失败,请重试',{
		                  icon : 2,
		              })
		          	},
		      	});
			},
			addResource:function(){
				var bId = addtion.bookInfo_id+0;
				var zId = addtion.bookInfo_zId+0;
				var jId = addtion.bookInfo_jId+0;
				//上传资源
				window.location.href="electiveResources.html"+ '?id=' + bId+'&zId='+zId+'&jId='+jId;
			},
			edit:function(id){
				//编辑资源信息
				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resDetail/'+id,
		          	success: function(data) {
			          	addtion.editList = data;
			          	if(data.types>=0){
	                        $("input[name='booktypes']").each(function(){
	                            if($(this).val()==data.types){
	                                $(this).prop('checked',true);
	                            }
	                        });
	                    }
			          	//编辑资源信息
						ope("编辑",'#book_edits','420px','420px');
		          	},
		          	error: function(response) {
		              	layer.alert('失败,请重试',{
		                  	icon : 2,
		              	})
		          	},
		      	});

			},
			code:function(id){
				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resDetail/'+id,
		          	success: function(data) {
		          	   $('#codePic').html('');
					   $('#imgOne').attr('src','');
		          		data.resource_url = data.resource_url;
			          	addtion.editList = data;
			          	//资源二维码
						ope("资源二维码",'#code','450px','480px');
						if(data.resource_url){
							var qrcode= $('#codePic').qrcode(data.resource_url).hide();
						   	var canvas=qrcode.find('canvas').get(0);
						   	$('#imgOne').attr('src',canvas.toDataURL('image/jpg'));
						}
		          	},
		          	error: function(response) {
		              layer.alert('失败,请重试',{
		                  icon : 2,
		              })
		          	},
		      	});
			},
			list:function(pId){
				addtion.bookInfo_id = pId;
				addtion.dataList = null;
				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/bookDetails/'+pId,
		          	success: function(data) {
		              	if(data.coverImage){
			              	data.coverImage= baseURL +'/public'+data.coverImage;
			          	}else{
			              	data.coverImage= '';
			          	}
			          	addtion.dataList = data;
			          	addtion.chapterList = data.chapterArr;
			          	setTimeout( autoLoad, 1 );
		          	},
		          	error: function(response) {
		              layer.alert('失败,请重试',{
		                  icon : 2,
		              })
		          	},
		      	});
				$('.left').css({display:"none"});
				$('.couseDetail').css({display:"block"});
				autoLoadResource(addtion.termId);
			},
			return:function(){
				addtion.bookInfo_id = 0;
				addtion.bookInfo_zId = 0;
				addtion.bookInfo_jId = 0;
				autoLoadResource(addtion.termId);
				$('.left').css({display:"block"});
				$('.couseDetail').css({display:"none"});
			},
			setZ:function(zId){
				addtion.bookInfo_zId = zId;
				autoLoadResource(addtion.termId);
			},
			setJie:function(jId){
				addtion.bookInfo_jId = jId;
				autoLoadResource(addtion.termId);
			},
			removeZj:function(){
				addtion.bookInfo_zId = 0;
				addtion.bookInfo_jId = 0;
				autoLoadResource(addtion.termId);
			},
			/*重新加载资源列表*/
			chooseTypes:function(type){
				var bId = addtion.bookInfo_id;
				var zId = addtion.bookInfo_zId;
				var jId = addtion.bookInfo_jId;
				addtion.type = type;

				$.ajax({
		          	type: "GET",
		          	url: baseURL + '/resourceUpload/'+bId+'/'+zId+'/'+jId+'/'+type,
		          	data:{term:addtion.termId},
		          	success: function(data) {
		          		for (var i = 0; i < data.length; i++) {
			      			if(data[i]['resource_url']){
			      				  var result = data[i]['resource_url'].substr(data[i]['resource_url'].length-3);
					              result = result.toLowerCase();
					        	  data[i]['resource_url'] = data[i]['resource_url'];
					               if( result =='pdf'){
				          			  data[i]['resource_urlOnline'] = data[i]['resource_url'];
				          			}
				                     else if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif'){
					          			data[i]['resource_urlOnline'] = 'https://view.officeapps.live.com/op/view.aspx?src='+data[i]['resource_url'];
					        			}else{
							                data[i]['resource_urlOnline'] = 'BookPic.html?u=' + data[i]['resource_url'];
							                data[i]['resource_url'] = 'BookPic.html?u=' + data[i]['resource_url'];
							              }
			      			}
			      		}
		              	// addtion.resourceList = data;
		              	addtion.resourceList = data.slice(0,10);
		              	layui.use('laypage', function(){
			                var laypage = layui.laypage;
			                laypage.render({
			                     elem: 'bookPage'
			                    ,count: data.length//数据总数，从服务端得到
			                    ,limit:10
			                    ,layout: ['count', 'prev', 'page', 'next', 'limit']
			                    ,curr:addtion.curr
			                    ,jump: function(obj, first){
			                      //obj包含了当前分页的所有参数，比如：
			                      var nowpage=obj.curr; //得到当前页，以便向服务端请求对应页的数据。
			                      var nownumber=obj.limit; //得到每页显示的条数
			                      if(!first){
			                        var start=(nowpage-1)*nownumber;
			                        var end=nowpage*nownumber;
			                        addtion.resourceList =data.slice(start,end);
			                      }
			                   }
			                });
			              });
		          	},
		          	error: function(response) {
		              	layer.alert('失败,请重试',{
		                  	icon : 2,
		              	})
		          	},
		      	});
			},
			sub:function(bId){
				var resName = $('#resName').val();
			 	var bookId = $('#editbookId').val();
	            var zhangId = $('#zhangId').val();
	            var jieId = $('#jieId').val();
	            var booktype = $('[name=booktypes]:checked').val();
	            // debugger;
				$.ajax({
		            type: "POST",
		            url: baseURL + '/saveResource',
	             	data:{
		                id:bId,
		                resName:resName,
		                bookId:bookId,
		                types:booktype,
		                zhangId:zhangId,
		                jieId:jieId,
		              },
		            success: function(data) {
		                addtion.resourceList = data;
		            },
		            error: function(response) {
		                layer.alert('保存失败，请重试',{
		                    icon : 2,
		                })
		            },
		        });
		        window.location.href="resourceManagement.html";
			},
			removeRes:function(bId){
				layer.confirm("确定删除？", function(){
					$.ajax({
			            type: "get",
			            url: baseURL + '/removeRes/'+bId,
		             	data:{
			                id:bId
		              	},
			            success: function(data) {
			                // addtion.resourceList = data;
			                var bId = bId;
			                layer.alert('删除成功！',{
			                    icon : 1,
			                })
			                autoLoadResource(addtion.termId);
			            },
			            error: function(response) {
			                layer.alert('删除失败，请重试',{
			                    icon : 2,
			                })
			            },
			        });
				})

		        // window.location.href="addition.html";
			},
			updateItems:function(){
				var data = $('.selectRes');
				downloadItems = [];
				downloadItems1 = [];
				for (var i = 0; i < data.length; i++) {
					var src = data[i].value.substr(data[i].value.length-3);
		            result = src.toLowerCase();
					if(data[i].checked==true){
						if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif' && result!='pdf'){
			          		downloadItems.push(data[i].value);
			        	}else{
			        		downloadItems1.push(data[i].value);
			        	}

					}
				}
			}
		}
	});

	//检查权限
    authCheck();
    function authCheck(){
      	$.ajax({
          	type: "GET",
          	url: baseURL + '/authCheck',
          	data:{action:"addtion/edit"},
          	success: function(data) {
              addtion.auth = data.auth;
          	},
          	error: function(response) {
              layer.alert('失败,请重试',{
                  icon : 2,
              })
          	},
      	});
    }

    //弹窗
	function ope(title,obj,width,height){
		layui.use('layer',function(){
			var layer = layui.layer;
		    layer.open({
			  type: 1,
			  title:title,
			  area: [width, height],
			  shadeClose: true,
              shade: false,
              maxmin: true, //开启最大化最小化按钮
              shadeClose: true,
              fixed: false,
              shade: false,
              maxmin: true, //开启最大化最小化按钮
			  content: $(obj),
			  end: function(index, layero){
				   $(obj).css({display:"none"});
				},
			});
		});
   }

   function autoLoad(){
		$('.list ul li p').clickdown();
      	$('.list-se p[class=title]').clickup();
		$('.list>ul>li').ad();
	}

	begin();
    function begin(){
	    //章节列表
	    $.ajax({
	        type: "GET",
	        url: baseURL + '/chapterListForSelect',
	        success: function(data) {
	            addtion.chapterLists = data.chapter;
	            addtion.nodeLists = data.node;
	        },
	        // error: function(response) {
	        //     layer.alert('章节列表加载失败，请重试',{
	        //         icon : 2,
	        //     })
	        // },
	    });
	    //获取当前学期
	    $.ajax({
	        type: "GET",
	        url: baseURL + '/termNow',
	        success: function(data) {
	            addtion.termId = data;
	            //课本列表
			    $.ajax({
			        type: "GET",
			        url: baseURL + '/resListForSelect',
			        data:{term:addtion.termId},
			        success: function(data) {
			            addtion.bookLists = data.list;
			        },
			        // error: function(response) {
			        //     layer.alert('课本列表加载失败，请重试',{
			        //         icon : 2,
			        //     })
			        // },
			    });
	            //加载资源
	            eleResorce(addtion.termId);

	            autoLoadResource(addtion.termId);
	        },
	        // error: function(response) {
	        //     layer.alert(response.responseJSON,{
	        //         icon : 2,
	        //     })
	        // },
	    });
	    //获取学期
	    $.ajax({
	        type: "GET",
	        url: baseURL + '/schoolYearList',
	        success: function(data) {
	          	addtion.term = data;
	          	//获取当前学年
	          	$.ajax({
	            	type: "GET",
	            	url: baseURL + '/schoolYearNow',
	            	success: function(response) {
	              		addtion.schoolYearId = response;
	            	},
	            	// error: function(response) {
	             //    	layer.alert(response.responseJSON,{
	             //        	icon : 2,
	             //    	})
	            	// },
	          	});
	        },
	        // error: function(response) {
	        //   	layer.alert('学期列表加载失败，请重试',{
	        //       	icon : 2,
	        //   	})
	        // },
	    });
    }

    //获取选修课本列表
	function eleResorce(term){
		$.ajax({
          	type: "GET",
          	url: baseURL + '/resourceList',
          	data:{term:term},
          	success: function(data) {
              	addtion.temp = data.datas;
              	addtion.listProject = data.list;
          	},
          	// error: function(response) {
           //    layer.alert('失败,请重试',{
           //        icon : 2,
           //    })
          	// },
      	});
	}

	//搜索查询
  	$("#schoolYearId").change(function(){
	    var schoolYearId = $("#schoolYearId").val();
	    $.ajax({
	        type: "GET",
	        url: baseURL + '/termNow',
	        data:{schoolYearId:schoolYearId},
	        success: function(data) {
	            addtion.termId = data;
	            //加载资源
	            eleResorce(addtion.termId);

	            autoLoadResource(addtion.termId);
	          },
	        error: function(response) {
	            layer.alert(response.responseJSON,{
	                icon : 2,
	            })
	        },
	    });
  	})

    /*加载资源*/
	function autoLoadResource(term){
		var bId = addtion.bookInfo_id;
		var zId = addtion.bookInfo_zId;
		var jId = addtion.bookInfo_jId;

		$.ajax({
          	type: "GET",
          	url: baseURL + '/resourceUpload/'+bId+'/'+zId+'/'+jId+'/'+3,
          	data:{term:term},
          	success: function(data) {
          		for (var i = 0; i < data.length; i++) {
	      			if(data[i]['resource_url']){
	      				  var result = data[i]['resource_url'].substr(data[i]['resource_url'].length-3);
			              result = result.toLowerCase();
			        		data[i]['resource_url'] = data[i]['resource_url'];
			        		   if( result =='pdf'){
			          			  data[i]['resource_urlOnline'] = data[i]['resource_url'];
			          			}
			                     else if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif'){
				          			data[i]['resource_urlOnline'] = 'https://view.officeapps.live.com/op/view.aspx?src='+data[i]['resource_url'];
				        			}else{
						                data[i]['resource_urlOnline'] = 'BookPic.html?u=' + data[i]['resource_url'];
						                data[i]['resource_url'] = 'BookPic.html?u=' + data[i]['resource_url'];
						              }
	      			}
	      		}
              	addtion.resourceList = data.slice(0,10);
              	layui.use('laypage', function(){
	                var laypage = layui.laypage;
	                laypage.render({
	                     elem: 'bookPage'
	                    ,count: data.length//数据总数，从服务端得到
	                    ,limit:10
	                    ,layout: ['count', 'prev', 'page', 'next', 'limit']
	                    ,curr:addtion.curr
	                    ,jump: function(obj, first){
	                      //obj包含了当前分页的所有参数，比如：
	                      var nowpage=obj.curr; //得到当前页，以便向服务端请求对应页的数据。
	                      var nownumber=obj.limit; //得到每页显示的条数
	                      if(!first){
	                        var start=(nowpage-1)*nownumber;
	                        var end=nowpage*nownumber;
	                        addtion.resourceList =data.slice(start,end);
	                      }
	                   }
	                });
	              });
          	},
          	// error: function(response) {
           //    layer.alert('失败,请重试',{
           //        icon : 2,
           //    })
          	// },
      	});
	}

	$('#batch').click(function(){
		$('#checkAll').show();
		$("a[name='selectA']").show();

	})

	$('#checkAll').click(function(){
		downloadItems = [];
		downloadItems1 = [];
		var data = $('.selectRes');
		for (var i = 0; i < data.length; i++) {
			var src = data[i].value.substr(data[i].value.length-3);
		    result = src.toLowerCase();
			if(result!='peg' && result!='bmp' && result!='dib' && result!='rle' && result!='emf' && result!='gif' && result!='jpg' && result!='jpe' && result!='jif' && result!='pcx' && result!='dcx' && result!='pic' && result!='png' && result!='tga' && result!='tif' && result!='xif' && result!='wmf' && result!='fif'){
		         downloadItems.push(data[i].value);
		      }else{
		        downloadItems1.push(data[i].value);
		       }
		}

     	$(".selectRes").prop('checked',true);
		$('#download').show();
		/*if($(this).attr('checked')){
		 	}else{
	     	$(".selectRes").prop('checked',false);
	   	} */
	})

  	var btn = document.getElementById('download');

 	function download(name, href) {
      	var a = document.createElement("a"), //创建a标签
          	e = document.createEvent("MouseEvents"); //创建鼠标事件对象
      	e.initEvent("click", false, false); //初始化事件对象
      	a.href = href; //设置下载地址
      	a.download = name; //设置下载文件名
      	a.dispatchEvent(e); //给指定的元素，执行事件click事件
  	}

  	//给多文件下载按钮添加点击事件
  	btn.onclick = function name(params) {
   	   	for (let index = 0; index < downloadItems.length; index++) {
	     	 download('第' + index + '个文件', downloadItems[index]);
      	}
	    for(var i=0;i<downloadItems1.length;i++){
	      	 var index = downloadItems1[i].indexOf('?u=');
	      	 downloadItems1[i] = downloadItems1[i].substring(index+3);
	      }
	    downloadItems1 = downloadItems1.join(',');
      	if(downloadItems1.length>0){
      		window.open('BookPic.html?u=' + downloadItems1,'_blank');
      	}
  	}

});
